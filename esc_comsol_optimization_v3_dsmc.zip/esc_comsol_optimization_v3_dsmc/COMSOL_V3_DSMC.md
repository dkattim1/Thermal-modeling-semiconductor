# COMSOL V3 DSMC integration

Use `hHe = hJump * C_DSMC` in the He-gap boundary flux. The correction is exported from Python as a smooth analytic polynomial so COMSOL Optimization retains smooth derivatives. COMSOL interpolation functions can also import file/table data for validation or reduced-dimensional tables. Define nominal, low and high He-conductance variants. MPh updates surrogate coefficients when the offline DSMC database is refreshed. Radiation remains a parallel path: `q_gap = hHe*(Taln-Tsi) + q_rad_gap`.
