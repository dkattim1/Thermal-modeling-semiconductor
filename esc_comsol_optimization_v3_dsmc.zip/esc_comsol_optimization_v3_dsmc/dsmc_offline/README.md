# Balanced offline DSMC / kinetic-He workflow

Production law:

    h_g = h_jump * C_DSMC

`h_jump` is a fast kinetic temperature-jump baseline. `C_DSMC` is a smooth correction learned from offline local-gap DSMC. DSMC is never called inside heater optimization.

Initial campaign: 64 LHS training + 16 anchors + 20 validation = about 100 cases. Add 20-case adaptive batches only if validation error or optimization sensitivity requires it.

Accuracy gate: target <=5% RMS and <=10% worst-case relative error in the DSMC correction over the validation set, then verify that re-fitting changes optimized warm-up time/critical margins by less than about 1-2%.

Sample variables: local pressure, gap, hot/cold wall temperatures, Si accommodation, AlN accommodation. Prefer SPARTA CLL wall scattering when normal/tangential accommodation data are available; otherwise diffuse wall scattering is a simpler starting model. Extract time-averaged wall energy flux and compute h_DSMC = |q|/|Th-Tc|.

Fit log(C_DSMC) with a smooth low-order polynomial in dimensionless/normalized variables such as log(Kn), Tmean, dT/Tmean, logit(alpha_Si), logit(alpha_AlN). A Gaussian-process model may be used offline only for uncertainty/adaptive sampling, while the production solver uses the analytic polynomial for smooth derivatives.

Robustness: retain h_nom, h_low, h_high. Optimize nominal first, then replay the optimum through low/high cases. Promote to scenario/robust optimization only if safety or uniformity margins are sensitive.
