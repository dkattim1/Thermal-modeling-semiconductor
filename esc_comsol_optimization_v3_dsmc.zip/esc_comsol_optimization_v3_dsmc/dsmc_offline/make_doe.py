from pathlib import Path
import json,csv,numpy as np
from scipy.stats import qmc
cfg=json.loads(Path('dsmc_config.json').read_text()); e=cfg['envelope']; c=cfg['campaign']; n=cfg['nominal']
def mapU(U):
  rows=[]; lp=np.log(e['pressure_Torr_log_range'])
  for u in U:
    p=float(np.exp(lp[0]+u[0]*(lp[1]-lp[0]))); g=e['gap_um_range'][0]+u[1]*(e['gap_um_range'][1]-e['gap_um_range'][0]); Tc=e['T_cold_K_range'][0]+u[2]*(e['T_cold_K_range'][1]-e['T_cold_K_range'][0]); dmax=min(e['deltaT_K_range'][1],e['T_hot_K_max']-Tc); dmin=min(e['deltaT_K_range'][0],max(1.,dmax)); dT=dmin+u[3]*max(0.,dmax-dmin); Th=Tc+dT; a1=e['alpha_Si_range'][0]+u[4]*(e['alpha_Si_range'][1]-e['alpha_Si_range'][0]); a2=e['alpha_AlN_range'][0]+u[5]*(e['alpha_AlN_range'][1]-e['alpha_AlN_range'][0]); rows.append([p,g,Th,Tc,a1,a2])
  return rows
train=mapU(qmc.LatinHypercube(d=6,seed=21).random(c['lhs_training_cases'])); valid=mapU(qmc.LatinHypercube(d=6,seed=72).random(c['validation_cases']))
anchors=[]
for p in [8,12,16,20]: anchors.append([p,n['gap_um'],n['T_AlN_K'],n['T_Si_K'],n['alpha_Si'],n['alpha_AlN']])
for g in [5,10,15,20]: anchors.append([n['pressure_Torr'],g,n['T_AlN_K'],n['T_Si_K'],n['alpha_Si'],n['alpha_AlN']])
for a in [0.15,0.3,0.5,0.7]: anchors.append([n['pressure_Torr'],n['gap_um'],n['T_AlN_K'],n['T_Si_K'],a,n['alpha_AlN']])
for a in [0.15,0.3,0.5,0.7]: anchors.append([n['pressure_Torr'],n['gap_um'],n['T_AlN_K'],n['T_Si_K'],n['alpha_Si'],a])
h=['case_id','set','pressure_Torr','gap_um','T_hot_K','T_cold_K','alpha_Si','alpha_AlN','q_wall_W_m2','q_wall_stderr_W_m2','h_DSMC_W_m2K','h_jump_W_m2K','C_DSMC']
with open('dsmc_cases.csv','w',newline='') as f:
 w=csv.writer(f); w.writerow(h); i=0
 for typ,rows in [('train',train),('anchor',anchors),('validation',valid)]:
  for r in rows: w.writerow([i,typ,*r,'','','','','']); i+=1
print('wrote',i,'cases')
