from pathlib import Path
import csv,json,numpy as np
from kinetic_baseline import h_jump,knudsen
def logit(a): a=np.clip(float(a),1e-4,1-1e-4); return np.log(a/(1-a))
def raw(r):
 p=float(r['pressure_Torr']); g=float(r['gap_um']); Th=float(r['T_hot_K']); Tc=float(r['T_cold_K']); Tm=.5*(Th+Tc)
 return np.array([np.log(knudsen(p,g,Tm)),Tm,(Th-Tc)/Tm,logit(r['alpha_Si']),logit(r['alpha_AlN'])])
def phi(x):
 z=[1.,*x.tolist()]
 for i in range(5):
  for j in range(i,5): z.append(x[i]*x[j])
 return np.array(z)
rows=list(csv.DictReader(open('dsmc_cases.csv'))); use=[]
for r in rows:
 if not r['q_wall_W_m2']: continue
 hd=abs(float(r['q_wall_W_m2']))/abs(float(r['T_hot_K'])-float(r['T_cold_K'])); hj=float(h_jump(float(r['pressure_Torr']),float(r['gap_um']),float(r['T_hot_K']),float(r['T_cold_K']),float(r['alpha_Si']),float(r['alpha_AlN']))); r['C']=hd/hj; use.append(r)
tr=[r for r in use if r['set']!='validation']; va=[r for r in use if r['set']=='validation']
if len(tr)<20: raise RuntimeError('Populate q_wall_W_m2 from DSMC first')
Xr=np.vstack([raw(r) for r in tr]); mu=Xr.mean(0); sd=Xr.std(0); sd[sd==0]=1; X=np.vstack([phi((x-mu)/sd) for x in Xr]); y=np.log([float(r['C']) for r in tr]); beta=np.linalg.lstsq(X,y,rcond=None)[0]
m={'mu':mu.tolist(),'sd':sd.tolist(),'beta':beta.tolist(),'feature_names':['logKn','Tmean_K','dT_over_Tmean','logit_alphaSi','logit_alphaAlN']}
if va:
 pred=[]; true=[]
 for r in va: pred.append(np.exp(phi((raw(r)-mu)/sd)@beta)); true.append(float(r['C']))
 rel=np.abs(np.array(pred)-np.array(true))/np.array(true); m['validation_rms_relative_error']=float(np.sqrt(np.mean(rel**2))); m['validation_max_relative_error']=float(rel.max()); print(m['validation_rms_relative_error'],m['validation_max_relative_error'])
Path('he_dsmc_correction_model.json').write_text(json.dumps(m,indent=2))
