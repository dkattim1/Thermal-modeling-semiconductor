import numpy as np
R=8.314462618; M=0.004002602; GAMMA=5/3; PR=0.67
def mu_he(T):
    T=np.asarray(T,float); mu0=1.96e-5; T0=300.; S=79.4
    return mu0*(T/T0)**1.5*(T0+S)/(T+S)
def k_he(T):
    cp=2.5*R/M
    return mu_he(T)*cp/PR
def mean_free_path(T,p_Pa):
    return mu_he(T)/p_Pa*np.sqrt(np.pi*(R/M)*T/2.)
def jump_length(T,p_Pa,alpha):
    a=np.clip(alpha,1e-4,1.0); lam=mean_free_path(T,p_Pa)
    return ((2-a)/a)*(2*GAMMA/(GAMMA+1))*lam/PR
def h_jump(p_Torr,gap_um,Th,Tc,aSi,aAlN):
    p=np.asarray(p_Torr,float)*133.32236842105263; g=np.asarray(gap_um,float)*1e-6; Tm=.5*(np.asarray(Th,float)+np.asarray(Tc,float))
    return k_he(Tm)/(g+jump_length(Tm,p,aSi)+jump_length(Tm,p,aAlN))
def knudsen(p_Torr,gap_um,Tm):
    return mean_free_path(Tm,np.asarray(p_Torr,float)*133.32236842105263)/(np.asarray(gap_um,float)*1e-6)
