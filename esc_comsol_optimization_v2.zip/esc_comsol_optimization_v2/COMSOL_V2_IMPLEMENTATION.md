# COMSOL V2 implementation additions

Use the shared `PHYSICS_SPEC_V2.md` as the authoritative physics contract.

## Mandatory additions relative to V1

### Radiation
Use `Surface-to-Surface Radiation` where geometry/view factors matter:
- wafer underside <-> AlN step
- wafer top/side <-> chamber/shields
- optionally AlN/Si across the 10 um He gap as a parallel radiative path

For the central He gap the total interface heat flux is:
`q_total = q_he_kinetic + q_rad_gap`.

### Rarefied He
Create an interpolation function such as:
`hHe(p,Tm,g,alphaSi,alphaAlN)`
from DSMC/kinetic/experimental data.
Do not use a standard continuum convective film coefficient without rarefaction correction.

Use:
`qhe = hHe(...) * (T_aln - T_si)`.

### Chucking pressure
Add either:
1. an interpolation/analytic function `Pchuck(r,T,Vchuck)`, or
2. Electrostatics physics and Maxwell-stress traction.

Recommended first implementation:
use measured/calibrated `Pchuck` so thermal optimization is not blocked by ESC electrical uncertainty.

Define:
`Pcontact = max(0, Pchuck + Ppreload - (Phe_local-Ptop))`

Then use `Pcontact` in the contact-conductance relation.

If wafer deflection matters, add Solid Mechanics to Si and couple contact/gap:
`g_local = g0 + w_aln - w_si` (sign convention to be checked).

### ESC type
Global string/enumeration-equivalent parameter:
`chuck_type = Coulomb/JR/empirical`

For JR behavior prefer measured/calibrated clamping-pressure relation unless a validated electro-contact model exists.

### Thermomechanics
Solid Mechanics:
- AlN/W always for crack-risk model
- Si additionally when bow/gap/contact coupling is enabled

### Bottom/support BC
Do not leave AlN thermally floating.
Parameterize actual support/base thermal path.

## Recommended study sequence
1. Forward thermal only
2. Thermal + radiation
3. Add kinetic He table
4. Add contact h(Pcontact)
5. Add AlN/W thermoelastic stress
6. Add chuck pressure
7. Add Si deformation/gap coupling if needed
8. Verify forward model
9. Run minimum-time optimization
