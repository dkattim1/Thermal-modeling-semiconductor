# MOOSE V3 DSMC integration

Use exactly the same production law as COMSOL: `h_He = h_jump*C_DSMC`. Implement the correction polynomial as an AD material/function so the nonlinear and adjoint systems retain derivatives. Do not call SPARTA inside MOOSE. Keep nominal/low/high He variants for robustness checks. Radiation remains a parallel heat-transfer path.
