from pprint import pprint
from comsol_driver import EscComsol

esc = EscComsol("config.json")
try:
    esc.set_base_conditions()
    esc.solve()
    pprint(esc.metrics())
finally:
    esc.close()
