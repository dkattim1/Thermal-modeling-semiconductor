# COMSOL base-model contract

## Named selections
Create stable named selections instead of relying on raw entity numbers:
- sel_wafer
- sel_wafer_he
- sel_wafer_contact
- sel_wafer_overhang
- sel_aln
- sel_W1, sel_W2, sel_W3, sel_W4
- sel_aln_top_he
- sel_aln_top_contact
- sel_overhang_bottom
- sel_overhang_side

## Global parameters
At minimum:
- P_he
- P_ch
- g_he
- Q_leak
- T_target

## Global result expressions
Expose:
- Twafer_mean
- Twafer_max
- Twafer_min
- AlN_dTdt_max
- AlN_sigma1_max
- Twafer_dTdt_absmax

## Physics
1. Heat Transfer in Solids: Si, AlN, W.
2. Electric Currents/Joule Heating if actual W geometry and electrical drive are modeled.
3. Solid Mechanics + thermal expansion for AlN/W stress.
4. Custom rarefied-He conductance h_he(P,T,g,alpha_Si,alpha_AlN).
5. Contact band: asperity solid conductance + He microgap conductance.
6. Radiation for wafer top and overhang top/bottom/side to chamber/step.
7. Do not use ordinary natural convection in the 10 um, 16 Torr He gap.

## Recommended optimization control
For hardware-faithful voltage slew:
- Add global ODE states V1..V4 with d(Vi,t)=ui(t).
- ui(t) are four optimized control functions representing voltage slew.
- Bound Vi, Ii, Pi and ui.
- Power follows Joule heating or Vi^2/Ri(T).

For direct power-command hardware use Pi states and optimize dPi/dt instead.
