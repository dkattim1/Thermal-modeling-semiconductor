# ESC COMSOL + Python optimization starter

Working assumptions:
- 6 in Si wafer, R=76.2 mm
- 3 mm overhang
- 3 mm nominal Si-AlN contact band inboard of overhang
- 10 um He gap at 16 Torr
- chamber ~1 mTorr
- leak ~1 sccm
- 4 radial AlN/W heater zones
- 5 mm ceramic step below overhang

Use COMSOL as the high-fidelity truth model. Use MPh for automation, calibration, sweeps, validation, and later ROM/control workflows.

Install:
`pip install MPh numpy scipy pandas matplotlib`

Put the base model at `esc_base.mph`, then run `python run_forward.py`.

MPh is best for automating an existing COMSOL model. Deep model creation/editing can still be done via `model.java` (COMSOL Java API), but maintaining one clean GUI-created base model with named selections is usually much easier.
