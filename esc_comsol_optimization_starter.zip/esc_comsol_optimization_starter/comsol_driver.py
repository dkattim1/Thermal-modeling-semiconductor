from pathlib import Path
import json, numpy as np, mph

class EscComsol:
    def __init__(self, config_path="config.json", cores=None, version=None):
        self.cfg = json.loads(Path(config_path).read_text())
        self.client = mph.start(cores=cores, version=version)
        self.model = self.client.load(self.cfg["comsol_contract"]["model_file"])

    def set_base_conditions(self):
        p = self.cfg["comsol_contract"]["parameters"]
        e = self.cfg["environment"]
        g = self.cfg["geometry"]
        self.model.parameter(p["Phe"], f'{e["he_pressure_torr"]}[Torr]')
        self.model.parameter(p["Pchamber"], f'{e["chamber_pressure_torr"]}[Torr]')
        self.model.parameter(p["gap"], f'{g["he_gap_um"]}[um]')
        self.model.parameter(p["leak"], f'{e["he_leak_sccm"]}[sccm]')
        self.model.parameter(p["Ttarget"], f'{e["target_temperature_C"]}[degC]')

    def solve(self, study_tag=None):
        if study_tag is None:
            self.model.solve()
        else:
            self.model.java.study(study_tag).run()

    def metrics(self):
        exprs = self.cfg["comsol_contract"]["expressions"]
        out = {}
        for key, expr in exprs.items():
            val = self.model.evaluate(expr, inner="last")
            arr = np.asarray(val, dtype=float)
            out[key] = float(arr.ravel()[0]) if arr.size == 1 else arr
        return out

    def save(self, path):
        self.model.save(path)

    def close(self):
        self.client.remove(self.model)
