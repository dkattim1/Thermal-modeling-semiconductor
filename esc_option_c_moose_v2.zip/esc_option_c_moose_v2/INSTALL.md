# Installation / manual work

## Recommended installation route

Use the official MOOSE installation instructions for your OS or a Linux workstation/container.
A Linux environment is strongly preferred for this stack.

Required capabilities in the MOOSE build:
- heat_transfer
- solid_mechanics
- optimization
- contact / fracture modules as needed
- PETSc/TAO

## What is manual compared with COMSOL

This option requires more manual engineering setup:
1. install/build MOOSE;
2. build the axisymmetric mesh and block/boundary IDs;
3. enter temperature-dependent material data;
4. define the actual AlN mechanical support BCs;
5. supply heater geometry or homogenized W volumes;
6. supply safe dT/dt and strength/stress criteria;
7. validate the He/contact models.

After that, the optimization itself is automated.

## Parameters still missing
- AlN total thickness
- W heater depth
- W track width/thickness or equivalent heater volume
- R_i(T), Pmax/Vmax/Imax
- AlN grade-specific material functions
- mechanical support/clamping details
- measured safe ceramic heating rate
- strength/fracture allowables
- exact He inlet/groove geometry
