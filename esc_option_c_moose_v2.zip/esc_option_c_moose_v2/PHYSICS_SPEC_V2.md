# Shared Physics Specification V2
Applies identically to:
1. COMSOL high-fidelity model
2. Open-source MOOSE/PETSc/TAO Option C

The numerical implementation differs; the physical model should not.

## 0. Core geometry currently assumed
- Si wafer radius: 76.2 mm
- Si wafer thickness: 675 um (assumption until confirmed)
- 3 mm overhang: 73.2-76.2 mm
- 3 mm nominal Si-AlN contact band: 70.2-73.2 mm
- He-supported region: 0-70.2 mm
- nominal He gap: 10 um
- backside He pressure: 16 Torr
- chamber pressure: ~1 mTorr
- leak/supply: ~1 sccm
- four radial heater zones:
  Z1 0-23.4 mm
  Z2 23.4-46.8 mm
  Z3 46.8-70.2 mm
  Z4 70.2-73.2 mm
- ceramic step under overhang: ~5 mm below wafer
- He inlet location remains parameterized because its reference edge is not yet fully resolved.

## 1. Solid heat conduction — REQUIRED
Solve transient heat conduction in:
- Si
- AlN
- W heater material (explicit or homogenized equivalent)

Use temperature-dependent material functions where available:
k(T), cp(T), rho(T if needed).

Full model:
rho cp dT/dt = div(k grad T) + q''' + boundary/interface fluxes

Radial and axial conduction are solved directly. No radial-lumped superposition assumption is used in the truth model.

## 2. Tungsten electrical/Joule heating — REQUIRED
Preferred detailed model:
J = sigma_W(T) E
q'''_J = J.E

At minimum:
R_i(T) from measured data or TCR
P_i = V_i^2/R_i(T) or I_i^2 R_i(T)

All 4 heater resistances and electrical limits can differ.

## 3. Rarefied helium heat transfer — REQUIRED, NOT OMITTED
The 10 um / 16 Torr He layer is NOT modeled as ordinary continuum convection.

Required production representation:
q''_He = h_He(p,T,g,alpha_Si,alpha_AlN) (T_AlN-T_Si)

h_He must be kinetic-informed.

Preferred hierarchy:
A. DSMC-derived lookup/surrogate over expected p,T,g,accommodation range (SPARTA or equivalent)
B. validated temperature-jump / kinetic-theory correlation
C. experimentally calibrated h_He table

The optimizer calls the table/correlation; it does NOT run DSMC every optimization iteration.

Inputs should include:
- local pressure p(r,t)
- local gap g(r,t)
- gas/surface temperatures
- accommodation coefficients
- optionally surface condition index if experiments support it

## 4. Helium leakage / pressure field — REQUIRED
The ~1 sccm leak is treated primarily as a rarefied-flow pressure-distribution problem:
supply/leak -> p(r,t) -> h_He(r,t)

Do NOT treat the leak as conventional forced-convection cooling of the wafer.
A quasi-steady pressure solution is acceptable relative to slow ceramic heating.

The annular inlet/groove geometry should be parameterized.

## 5. Radiation — REQUIRED
Radiation is included explicitly.

### 5.1 Central He gap
Parallel path:
q'' = q''_He + q''_rad,gap

Use far-field surface radiation as baseline:
q''_rad,gap = eps_eff sigma_SB (T_AlN^4 - T_Si^4)
with appropriate facing-surface emissivities/view factor.

At 10 um separation, this is normally much smaller than 16-Torr He conduction but is retained so it is not silently omitted.

### 5.2 Nominal contact/microgap region
Effective interface:
h/contact solid + He microgap conduction + radiative microgap path where physically open.

### 5.3 Overhang
Include:
- top radiation to upper chamber/process surfaces
- bottom radiation to lower AlN step
- outer sidewall radiation

Use surface-to-surface view factors where geometry is known rather than assuming F=1.

### 5.4 Other exposed ceramic surfaces
Include radiation to chamber/shields where thermally relevant.

## 6. Si-AlN contact band — REQUIRED
Nominal contact is NOT perfect contact.

Local heat flux includes:
q''_contact =
  h_asperity(P_contact,T,roughness,hardness,materials)*(T_AlN-T_Si)
+ h_He_microgap(p,T,g_micro)*(T_AlN-T_Si)
+ q''_rad_microgap

Initial asperity model may use CMY/Yovanovich-type contact conductance.
Final h_contact should be calibrated experimentally.

## 7. Chucking pressure / electrostatic force — REQUIRED in V2
This is now explicit rather than hidden inside h_contact.

Define:
P_contact(r,t) = max(0,
  P_chuck(r,t)
  + P_mech_preload(r,t)
  - [P_He(r,t)-P_top(r,t)]
)

P_top is approximately chamber/process pressure unless another top-side pressure exists.

P_contact feeds:
- asperity contact conductance
- true/nominal contact fraction model
- microgap size/statistics
- wafer deflection/contact state

### 7.1 Preferred inputs
Best practical option if available:
measured/calibrated P_chuck(r,T,V_chuck)

### 7.2 Physics-based option
Solve electrostatics and compute electrostatic traction / Maxwell stress.

For a purely Coulomb ESC this can be modeled directly from the electric field/dielectric stack.

For Johnson-Rahbek behavior, a simple parallel-plate pressure law is not enough; use a calibrated electro-contact model or measured clamp-force relation because ceramic resistivity/contact-potential physics matter.

Parameter:
chuck_type = Coulomb | JR | empirical

## 8. Wafer mechanics / bow / gap coupling — RECOMMENDED, REQUIRED for highest fidelity
If chucking pressure or thermal bow materially changes the 10 um gap:
solve wafer mechanics quasi-statically.

Outputs:
- wafer deflection w(r,t)
- local He gap g(r,t)
- contact/open state in edge band
- local contact pressure distribution

Coupling:
P_chuck -> deformation/contact -> g and P_contact
g,p -> h_He / h_microgap
temperature -> thermal strain -> deformation
This closes the electro-thermo-mechanical feedback loop.

If measurements show gap shape is fixed, a prescribed g(r) can be used in the first model.

## 9. AlN/W thermo-mechanical stress and cracking — REQUIRED
Solve quasi-static mechanics with thermal strain:
eps_th = alpha(T)(T-Tref)

Monitor:
- maximum principal tensile stress in AlN
- W/AlN interface stress
- radial and through-thickness thermal gradients
- experimentally known maximum dT/dt

Hard constraints can include:
|dT_AlN/dt| <= beta_max
sigma1_AlN <= sigma_allow(T)/SF
optional |grad T| <= Gmax

A 2-D axisymmetric global model may homogenize W tracks.
Use a local 3-D heater-track model for final crack verification.

## 10. AlN support / base losses — REQUIRED boundary condition
The ceramic cannot be thermally floating unless that is physically true.

Model the lower/back/side support by the actual system:
- fixed/controlled base temperature, or
- contact resistance to pedestal/base, or
- coolant boundary, or
- measured equivalent h/Rth.

This boundary can strongly affect warm-up time and heater-zone interaction.

## 11. Top-side process heat input — PARAMETERIZED
If plasma/radiation/process heating is OFF during warm-up:
set q''_process = 0.

If it exists:
include q''_process(r,t) as a boundary heat source.
Do not bury it in an effective heater calibration.

## 12. Minor/optional heat paths
Include if measurements show significance:
- heat conduction through electrical leads
- sensor wiring
- mounting contacts
- gas-line conduction
These are usually lower priority than the main paths above.

## 13. What is intentionally NOT modeled as normal convection
- No natural convection in the 10 um He gap
- No ordinary continuum forced convection for ~1 sccm He leakage
- No ordinary natural convection in ~1 mTorr overhang space

## 14. Superposition / linearity
The local ENERGY BALANCE is additive:
q_total = q_W + q_He + q_contact + q_rad + q_support + q_process + ...

But this does NOT imply that the TEMPERATURE SOLUTION is superposable.

Strict temperature-field superposition is valid only if the governing system is linear, e.g.:
- constant k, cp
- fixed h_He and h_contact
- linear boundary conditions
- no T^4 radiation
- no R_W(T)
- no pressure/contact/gap dependence on T or deformation
- no changing contact state

The full V2 model is nonlinear because of:
- k(T), cp(T)
- R_W(T)
- radiation T^4
- h_He(p,T,g,alpha)
- h_contact(P_contact,T,...)
- chucking/gap/contact coupling
- thermal deformation/contact changes

Therefore:
T(P1+P2) != T(P1) + T(P2) in general.

However, around a fixed operating point the full model can be linearized:
delta x_dot = A delta x + B delta u
and then local superposition is approximately valid.
This is useful for:
- influence matrices
- system identification
- linear MPC
- small perturbation control
but not for the full 25C -> 400C optimization.

## 15. Optimization variables remain
Primary controls:
P1(t), P2(t), P3(t), P4(t)
or hardware-native V_i(t)/I_i(t)

Minimum-time variable:
tf

Optional design/control variables later:
- chuck voltage trajectory V_chuck(t)
- He pressure trajectory P_He,set(t)
- heater zone radii
- heater depth/geometry

If chuck voltage is not actively varied, it remains a parameter/state relation that still affects contact physics.
