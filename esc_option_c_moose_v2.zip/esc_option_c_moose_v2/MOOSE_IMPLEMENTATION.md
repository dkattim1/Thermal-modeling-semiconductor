# MOOSE implementation strategy

## Why MOOSE for Option C

MOOSE is the preferred no-COMSOL high-fidelity path here because it already provides:
- Heat Transfer
- Solid Mechanics
- contact/fracture-related modules
- PETSc nonlinear/linear solvers
- an Optimization module
- a TransientAndAdjoint executioner.

The current transient adjoint is based on backward adjoint integration and currently requires Implicit Euler for a consistent adjoint. It stores forward states, so memory grows with mesh size x number of time steps.

## Model hierarchy

### Global optimizer model
2-D axisymmetric approximation:
- explicit AlN cross-section
- four homogenized W annular heater domains
- Si wafer
- rarefied-He interface model
- nominal contact band
- overhang radiation
- coupled AlN thermoelastic stress

### Verification submodels
1. 3-D W-track / AlN local stress model.
2. Optional 3-D azimuthal model for actual heater routing and gas-feed nonuniformity.
3. DSMC or experimental He conductance table.

## Time-dependent controls

Use `N` power values per zone:
- `P1[0:N-1]`
- `P2[...]`
- `P3[...]`
- `P4[...]`

and linearly interpolate in normalized time.

MOOSE's optimization functions can interpolate parameter vectors in time; a ParameterMeshFunction is one current route. An alternative is a small custom OptimizationFunction that interpolates a reporter vector over time.

The optimization variables are the four control vectors and scalar `tf`.

## Automatic adjoint

The forward PDE and its coupled mechanics are solved over normalized time.

The adjoint then steps backward through the saved forward states and generates gradients of:
- objective
- terminal constraints
- path constraints

with respect to the heater-control coefficients and `tf`.

For source-control gradients, MOOSE provides optimization inner-product objects for parameterized source functions.

## Constraint aggregation

Do not create thousands of pointwise stress constraints for the first model.
At each time step compute smooth aggregated:
- AlN dT/dt limit
- AlN tensile stress limit
- wafer temperature spread.

Then either:
- constrain maximum KS value over time, or
- constrain these quantities at a finite set of control/check times.

The latter is easier for the first implementation.

## Solver

Start with a constrained TAO algorithm through MOOSE:
- ALMM for general inequality constraints is a practical starting point.

Do not use GA/PSO for the full PDE model.

## Scaling

Scale optimization variables:
- `tf`: O(1) after scaling by 100 s
- powers: O(1) after scaling by each zone Pmax
- temperatures: scale by 400 K
- stress: scale by allowable stress.

Poor scaling can dominate convergence.

## Gradient verification

Before optimizing:
1. choose a random heater trajectory,
2. compute adjoint gradient,
3. compare against finite difference for several parameters,
4. require first-order gradient agreement / Taylor-test behavior.

Never trust a PDE-constrained optimization before gradient verification.
