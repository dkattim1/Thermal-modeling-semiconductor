# MOOSE Option C V2 implementation additions

Use `PHYSICS_SPEC_V2.md` as the authoritative physical model.

## Radiation
Implement radiative boundary/interface kernels:
- Si underside <-> AlN step
- Si top/side <-> chamber/shields
- AlN <-> Si across He gap as a parallel radiation path

For view-factor radiation, either:
- implement a geometry-specific radiosity/view-factor relation, or
- precompute view factors externally for the axisymmetric geometry and feed them as parameters/functions.

## Rarefied helium
Recommended:
- generate `hHe(p,T,g,alpha)` table from SPARTA/DSMC or validated kinetic correlation
- use interpolation material/function in MOOSE
- pressure field may be a quasi-steady external lookup/function

## Chucking pressure
V2 requires explicit:
`Pcontact = max(0, Pchuck + Ppreload - (Phe-Ptop))`

Implementation options:
A. recommended first: calibrated reporter/function `Pchuck(r,T,Vchuck)`
B. MOOSE electrostatics module + custom Maxwell-traction coupling

MOOSE has electrostatic/electromagnetic infrastructure, but a production ESC Maxwell-pressure/contact coupling may require custom kernels/materials. Therefore measured/calibrated pressure is the fastest reliable first implementation.

## Wafer mechanics
Add Si solid mechanics if bow/contact/gap variations are important.
Couple local gap and contact state into He/contact conductance.

## Optimization
No superposition assumption is used in the full PDE-constrained optimization.
The adjoint differentiates the nonlinear coupled residual.

A linearized ROM may be produced later for MPC.
