# Mathematical model

## 1. Decision variables

With N control knots per heater:

\[
\mathbf z =
[t_f,\ P_{1,1},...,P_{1,N},\ P_{2,1},...,P_{4,N}]^T
\]

The recommended first formulation optimizes **electrical power delivered to each heater zone**. Different heater resistances are imposed through electrical feasibility constraints:

\[
V_i(s)=\sqrt{P_i(s) R_i(T_{W,i})}
\]

\[
I_i(s)=\sqrt{\frac{P_i(s)}{R_i(T_{W,i})}}
\]

with

\[
R_i(T)=R_{i,0}[1+\alpha_{R,i}(T-T_0)]
\]

or a measured tabulated \(R_i(T)\).

This is cleaner than optimizing voltage initially because the thermal PDE is driven by power. A second formulation can optimize voltage directly after the electrical model is validated.

---

## 2. Objective

Primary objective:

\[
\min_{\mathbf z} t_f
\]

Optional very small regularization:

\[
J=t_f
+\lambda_P\sum_i\int_0^1\left(\frac{dP_i}{ds}\right)^2ds
+\lambda_U\int_0^1 \Delta T_w(s)^2 ds.
\]

The regularization terms should remain secondary; otherwise they can make a safe solution unnecessarily slow.

---

## 3. Normalized time

Let

\[
t=t_fs,\qquad s\in[0,1].
\]

Then

\[
\frac{\partial T}{\partial t}
=\frac{1}{t_f}\frac{\partial T}{\partial s}.
\]

The physical heat equation

\[
\rho c_p\frac{\partial T}{\partial t}
-\nabla\cdot(k\nabla T)=q'''
\]

becomes

\[
\rho c_p\frac{\partial T}{\partial s}
-t_f\nabla\cdot(k\nabla T)
=t_f q'''.
\]

All physical heat-flux boundary terms are similarly multiplied by \(t_f\) in the normalized-time residual.

This allows \(t_f\) to be an ordinary design variable while MOOSE always integrates from 0 to 1.

---

## 4. AlN / W / Si thermal physics

For each solid material \(m\):

\[
\rho_m c_{p,m}(T)\frac{\partial T}{\partial s}
-
t_f\nabla\cdot[k_m(T)\nabla T]
=
t_f q'''_m.
\]

Use temperature-dependent:
- \(k(T)\)
- \(c_p(T)\)
- electrical resistivity for W
- CTE, modulus and Poisson ratio for mechanics.

---

## 5. Heater zones

For homogenized axisymmetric zone \(i\):

\[
q'''_{W,i}(s)=\frac{P_i(s)}{V_{W,i}}.
\]

This is the recommended global optimization model.

For local crack verification, replace each annular homogenized zone with a 3-D tungsten track submodel.

---

## 6. Rarefied helium zone

For the central region, do not use ordinary continuum convection.

Use a heat-transfer coefficient:

\[
q''_{He}=h_{He}(p,T,g,\alpha_{Si},\alpha_{AlN})
(T_{AlN}-T_{Si}).
\]

A first analytical model may use a temperature-jump effective gap:

\[
h_{He} =
\frac{k_{He}(T)}
{g+\ell_{T,Si}+\ell_{T,AlN}}
\]

with

\[
\ell_T=
\frac{2-\alpha}{\alpha}
\frac{2\gamma}{\gamma+1}
\frac{\lambda}{Pr}.
\]

Mean free path:

\[
\lambda=
\frac{\mu}{p}
\sqrt{\frac{\pi R T}{2M}}.
\]

At the present \(16\) Torr and \(10\,\mu m\) gap the gas is transitional/molecular, so this analytic model must eventually be calibrated or replaced by a table from DSMC/experiment.

Recommended production implementation:
\[
h_{He} = \text{tabulated/interpolated function}(p,T,g)
\]
rather than embedding an uncertain analytic formula in the final optimizer.

---

## 7. Helium leakage

The ~1 sccm leak is **not modeled as ordinary forced convection heat transfer**.

Its main thermal effect is:
\[
\dot m \rightarrow p(r)\rightarrow h_{He}(r).
\]

For the first optimization:
- measured/regulator pressure = 16 Torr in the He zone,
- use a prescribed or calibrated radial \(p(r)\) near the edge.

A later high-fidelity extension can solve a quasi-steady rarefied-flow pressure model externally and supply \(p(r)\) to MOOSE.

---

## 8. Si-AlN contact band

Use parallel contributions:

\[
h_c(r,T)
=
h_{asperity}
+
h_{He,microgap}.
\]

A CMY/Yovanovich-type initial contact model is:

\[
h_{asperity}
\sim
C k_s\frac{m}{\sigma}
\left(\frac{P_c}{H_c}\right)^n.
\]

The exact \(h_c\) should be calibrated from experimental temperature data because roughness, chuck pressure and microscopic gap statistics dominate uncertainty.

---

## 9. Overhang

The 3-mm overhang receives no high-pressure He or direct solid contact underneath.

Energy transport includes:
- radial Si conduction,
- top radiation,
- bottom radiation to the AlN step,
- sidewall radiation.

Radiation:

\[
q''_{rad}
=
\epsilon_{eff}F\sigma_{SB}
(T_{Si}^4-T_{sur}^4).
\]

No natural convection is required for the ~1 mTorr vacuum space.

---

## 10. Thermoelastic mechanics

At each transient state solve quasi-static equilibrium:

\[
\nabla\cdot\sigma=0.
\]

Thermal strain:

\[
\epsilon^{th}
=
\alpha(T)(T-T_{ref})I.
\]

Stress:

\[
\sigma=C(T):
(\epsilon-\epsilon^{th}).
\]

The main failure quantity is maximum principal tensile stress in AlN:

\[
\sigma_1^{max}(s).
\]

A local 3-D W/AlN submodel should eventually evaluate tungsten-track stress concentration and CTE mismatch.

---

## 11. Hard constraints

### Heater bounds
\[
0\le P_i(s)\le P_{i,max}.
\]

### Electrical feasibility
\[
V_i(s)\le V_{i,max},\qquad I_i(s)\le I_{i,max}.
\]

### Power slew
For piecewise control points:
\[
\left|\frac{P_{i,k+1}-P_{i,k}}
{t_f(s_{k+1}-s_k)}\right|
\le \dot P_{i,max}.
\]

### Ceramic heating-rate
\[
\max_{\Omega_{AlN}}
\left|\frac{\partial T}{\partial t}\right|
=
\max
\left|\frac1{t_f}\frac{\partial T}{\partial s}\right|
\le \beta_{max}.
\]

### Ceramic stress
\[
\sigma_1^{max}(s)
\le \frac{\sigma_{allow}(T)}{SF}.
\]

### Optional spatial-gradient limit
\[
|\nabla T_{AlN}|\le G_{max}.
\]

### Wafer transient uniformity
If required:
\[
T_{w,max}(s)-T_{w,min}(s)
\le \Delta T_{ramp,max}.
\]

### Terminal mean temperature
\[
|\overline T_w(1)-T_{target}|
\le \epsilon_T.
\]

### Terminal uniformity
\[
T_{w,max}(1)-T_{w,min}(1)
\le \Delta T_{final}.
\]

### Terminal settling
\[
\max_{\Omega_w}
\left|\frac{\partial T}{\partial t}(1)\right|
\le \epsilon_{\dot T}.
\]

---

## 12. Smooth aggregation for gradients

Raw spatial maxima can be nonsmooth when the critical location moves.

For optimization use a KS or p-norm approximation, e.g.

\[
KS_\rho(g)=
\frac1\rho
\ln\left[
\frac1{|\Omega|}
\int_\Omega e^{\rho g(x)}d\Omega
\right].
\]

Validate the optimized design afterward using true maxima.

---

## 13. Robust extension

After nominal optimization, treat:
- \(h_c\),
- He accommodation coefficients,
- emissivities,
- AlN properties,
- heater resistance,
- clamp pressure

as uncertain.

Then solve either:
- worst-case robust optimization,
- scenario constrained optimization,
- chance-constrained optimization.

The first optimization should remain deterministic until the model is calibrated.
