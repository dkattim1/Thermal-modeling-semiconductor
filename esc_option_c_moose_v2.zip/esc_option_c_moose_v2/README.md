# Option C: fully open-source PDE-constrained optimal control

This is the independent no-COMSOL implementation path for the four-zone AlN/W ESC heater problem.

## Core stack
- **MOOSE**: transient thermal + thermo-mechanical finite elements
- **MOOSE Optimization Module**: forward/adjoint orchestration
- **PETSc/TAO**: large-scale constrained optimization
- **Gmsh / MOOSE mesh generators**: mesh
- **Python**: configuration, initial trajectories, parameter studies, result processing
- **ParaView**: field visualization

## Why this stack
The target problem is not just heat conduction. It couples:
1. temperature-dependent AlN/W/Si conduction,
2. four independent heater power histories,
3. rarefied-He interface conductance,
4. Si-AlN contact/asperity conductance,
5. overhang radiation and edge losses,
6. wafer radial spreading,
7. thermoelastic stress and ceramic crack limits,
8. minimum-time optimal control.

MOOSE currently has a transient-and-adjoint executioner and an Optimization module using PETSc/TAO. This makes it suitable as a full PDE-constrained alternative to COMSOL.

## Important implementation choice: normalized time
Run the forward transient on a fixed normalized coordinate s in [0,1].
The physical final time tf is an optimization variable.

For a thermal PDE:
    rho cp dT/dt - div(k grad T) = q

with t = tf*s:
    rho cp dT/ds - tf*div(k grad T) = tf*q

Thus the computational time interval never changes while tf is optimized.

## Controls
Use four piecewise-linear power histories:
    P1(s), P2(s), P3(s), P4(s)

Each has N control-knot values. Those values plus tf are optimization variables.

This avoids manually optimizing heater sequence. Start time, overlap, ramp, hold and taper emerge from the optimized functions.

## Status of this package
This is a detailed implementation scaffold, not a turnkey executable model, because the exact AlN thickness, heater depth, electrical limits, AlN grade and mechanical constraints are not yet known. The MOOSE templates mark those locations explicitly.

See:
- `MODEL_MATH.md`
- `MOOSE_IMPLEMENTATION.md`
- `moose/main_optimize.i.template`
- `moose/forward_and_adjoint.i.template`
