import json
from pathlib import Path
import numpy as np
import csv

cfg = json.loads(Path("../assumptions.json").read_text())
N = cfg["heaters"]["control_knots"]
s = np.linspace(0.0, 1.0, N)

# Conservative generic initial trajectory:
# edge zones lead mildly; all values are normalized fractions of Pmax.
profiles = {
    "P1": np.clip((s-0.10)/0.55, 0, 1),
    "P2": np.clip((s-0.07)/0.55, 0, 1),
    "P3": np.clip((s-0.03)/0.55, 0, 1),
    "P4": np.clip((s-0.00)/0.55, 0, 1),
}

# Taper near the end to help settling. This is only an initial guess.
for k in profiles:
    profiles[k] *= (1.0 - 0.15*np.clip((s-0.8)/0.2, 0, 1))

with open("initial_controls.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["s","P1_frac","P2_frac","P3_frac","P4_frac"])
    for j in range(N):
        w.writerow([s[j], profiles["P1"][j], profiles["P2"][j],
                    profiles["P3"][j], profiles["P4"][j]])

print("Wrote initial_controls.csv")
