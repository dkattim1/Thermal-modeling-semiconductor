import numpy as np

def resistance_linear(T_K, R0, T0_K, alpha_R):
    return R0 * (1.0 + alpha_R * (T_K - T0_K))

def electrical_from_power(P_W, R_ohm):
    P_W = np.maximum(np.asarray(P_W, float), 0.0)
    R_ohm = np.maximum(np.asarray(R_ohm, float), 1e-12)
    V = np.sqrt(P_W * R_ohm)
    I = np.sqrt(P_W / R_ohm)
    return V, I

def slew(values, tf_s, s_knots):
    """Physical dP/dt from controls expressed on normalized time s."""
    values = np.asarray(values, float)
    s_knots = np.asarray(s_knots, float)
    return np.diff(values) / (tf_s * np.diff(s_knots))
